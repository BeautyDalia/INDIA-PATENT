# -*- coding: utf-8 -*-

from items import IntroItem,DetailItem,SpecificationItem,LastItem
from codecs import open
import redis
import os

class IndiaProjectPipeline(object):

    def __init__(self):
        if not os.path.exists("specification"):
            os.mkdir("specification")
        self.db = redis.StrictRedis(host="localhost", port=6379, db=0)
        self.intro_file = open("intro.csv", "a+", encoding="utf-8")
        self.detail_file = open("detail.csv", "a+", encoding="utf-8")
        self.error_data = open("error.csv", "a+", encoding="utf-8")

    def __del__(self):
        self.intro_file.close()
        self.detail_file.close()
        self.error_data.close()

    def process_item(self, item, spider):
        try:
            if isinstance(item, IntroItem):
                print "write intro_data==> [%s]" % item["app_num"]
                self.intro_file.write(item["app_num"]+"==> ")
                self.intro_file.write(item["intro_data"])
                self.intro_file.write("\n")
            elif isinstance(item, DetailItem):
                print "write detail_data==> [%s]" % item["app_num"]
                self.detail_file.write(item["app_num"]+"==> ")
                self.detail_file.write(item["detail_data"])
                self.detail_file.write("\n")
            elif isinstance(item, SpecificationItem):
                print "write specification==> [%s]" % item["app_num"]
                detail_link_text = item["app_num"].replace("/","_").strip()
                with open("specification/%s/%s" % (item["year"], detail_link_text), "w+", encoding="utf-8") as sp:
                    sp.write(item["specification"])
            else:
                self.db.set(item["year"],item["new_to_date"])
            if dict(item).get("app_num"):
                detail_link_text=item["app_num"].replace("/","_").strip()
                self.db.set(detail_link_text + "-data","1")
            print "==============<PIPELELINE DONE>================"
        except Exception as e:
            print "Error: %s" % e
            self.error_data.write(json.dumps(item))
        return item
