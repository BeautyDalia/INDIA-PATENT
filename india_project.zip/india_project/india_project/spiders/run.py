#coding:utf8

from scrapy import cmdline
import time

while True:
    try:
        cmdline.execute('scrapy crawl india -a year=2008 -a data_type=1'.split())
        time.sleep(10)
    except Exception as e:
        print "ERROR: %s" % e
        time.sleep(30)
        continue