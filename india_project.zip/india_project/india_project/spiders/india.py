# -*- coding: utf-8 -*-

from numpy import array
import subprocess
import re
import redis
from PIL import Image
import scrapy
import os, time
from scrapy import Request,FormRequest
from india_project.util.parse_content import ReadHtml
from india_project.items import IntroItem,DetailItem,SpecificationItem,LastItem

class IndiaSpider(scrapy.Spider):

    name = 'india'
    allowed_domains = ['ipindiaservices.gov.in']
    start_urls = ['http://ipindiaservices.gov.in/PublicSearch/Captcha/GetCaptchaImage']

    def __init__(self, year, data_type, *args, **kwards):
        self.year = year
        self.data_type = "Published" if int(data_type)==1 else "Granted"
        self.specification_path = "specification/%s/"%self.year
        if not os.path.exists(self.specification_path):
            os.makedirs(self.specification_path)
        self.pdf_path = "pdfs/%s/"%self.year
        if not os.path.exists(self.pdf_path):
            os.makedirs(self.pdf_path)
        self.readhtml = ReadHtml()
        self.db = redis.StrictRedis(host="localhost", port=6379, db=0)   
        super(IndiaSpider, self).__init__(*args, **kwards)

    def parse(self, response):
        self.from_date = '01/01/%s'%self.year
        self.to_date = '12/31/%s'%self.year
        with open('GetCaptchaImage_cover.png', 'w') as code_image:
            code_image.write(response.body)
        im = array(Image.open("GetCaptchaImage_cover.png").convert('L'))
        for y_num, y_line in enumerate(im):
            for x_num,x_line in enumerate(y_line):
                im[y_num][x_num] = 255 if x_line>=110 else 0
            door = 2
            black_list = []
            for x_num, x_line in enumerate(y_line):
                if x_line < 140:
                    black_list.append((x_num, x_line))
                else:
                    if len(black_list) < door:
                        for x,y in black_list:
                            im[y_num][x] = 255
                    black_list = []
        image = Image.fromarray(im)
        image.save("GetCaptchaImage_cover.png")
        subprocess.call("tesseract GetCaptchaImage_cover.png out -psm 70 -c tessedit_char_whitelist='1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'", shell=True)
        with open("out.txt","r") as out:
            code = out.read().strip()
        print "code is: %s" % code 
        if code and len(code) == 5:
            search_url = "http://ipindiaservices.gov.in/PublicSearch/PublicationSearch/Search"
            data = {"CaptchaText": code, "Published": "false", "Granted": "false", "DateField": "APD",
                "FromDate": self.from_date, "ToDate": self.to_date, "LogicField": "AND", "ItemField1": "TI",
                "TextField1": "", "LogicField1": "AND", "ItemField2": "ABS", "TextField2": "", "LogicField2": "AND",
                "ItemField3": "CSP", "TextField3": "", "LogicField3": "AND", "ItemField5": "AP", "TextField5": "",
                "LogicField5": "AND", "ItemField6": "patent-number", "TextField6": "", "LogicField6": "AND",
                "ItemField7": "PA", "TextField7": "", "LogicField7": "AND", "ItemField8": "IN", "TextField8": "",
                "LogicField8": "AND", "ItemField9": "INC", "TextField9": "", "LogicField9": "AND",
                "ItemField10": "INA", "TextField10": "", "LogicField10": "AND", "ItemField11": "FO",
                "TextField11": "", "LogicField11": "AND", "ItemField12": "TI", "TextField12": "",
                "LogicField12": "AND", "ItemField13": "PAP", "TextField13": "", "LogicField13": "AND",
                "ItemField14": "PPN", "TextField14": "", "submit": "Search"}
            data[self.data_type]="true"
            print u"==>提交验证码"
            yield FormRequest(search_url, formdata=data, callback=self.parse_search_list, errback=self.parse_error, dont_filter=True)
        else:
            yield Request(self.start_urls[0], callback=self.parse, errback=self.parse_error, dont_filter=True)

    def parse_search_list(self, response):
        number = response.meta.get("number", 1)
        print number,"*****"
        if 'name="CaptchaText" id="CaptchaText"' in response.text:
            print(u"验证码不正确") 
            yield Request(self.start_urls[0], callback=self.parse, errback=self.parse_error, dont_filter=True)
        else:
            print "==> in parse_search_list"
            detail_links = response.xpath("//button[@name='ApplicationNumber']/@value").extract()
            all_num = response.xpath("//div[@class='col-lg-3']/text()").extract_first(default="")
            pa = re.compile(r"\d+")
            all_num = "".join(pa.findall(all_num))
            print u"本页专利数量: [%s]  需抓取的总量：%s" % (len(detail_links), all_num)
            for app_number in detail_links:
                app_number = app_number.strip()
                detail_link_text = app_number.replace("/","_")
                response.meta["app_number"] = app_number
                pdfs_path = os.path.join("pdfs",self.year,detail_link_text)
                print "======>pdf path: %s" % pdfs_path
                if self.db.get(detail_link_text+"-data") and os.path.exists(pdfs_path):
                    print(u"    ==>redis发现 %s,跳过。" % app_number)
                    continue
                detail_url = "http://ipindiaservices.gov.in/PublicSearch/PublicationSearch/PatentDetails"
                data = {"ConnectionName":"PublicationConnection","ApplicationNumber":app_number}
                response.meta["number"] = number
                response.meta["detail_link_text"] = detail_link_text
                yield FormRequest(detail_url, formdata=data, callback=self.parse_intro, meta=response.meta, errback=self.parse_error, dont_filter=True)
            more = response.xpath("//button[@class='next' and @name='page']/@disabled").extract_first(default="")
            new_to_date = response.xpath("//table[@id='tableData']/tbody/form/tr/td[3]/text()").extract_first().strip()
            new_to_date_list = new_to_date.strip().split("/")
            new_to_date_list.insert(1,new_to_date_list.pop(0))
            new_to_date = "/".join(new_to_date_list)
            item = LastItem()
            item["new_to_date"]=new_to_date
            item["year"]= self.year
            yield item
            total_pages = response.xpath("//button[@class='last' and @name='page']/@value").extract_first()
            page_url = "http://ipindiaservices.gov.in/PublicSearch/PublicationSearch/PatentSearchResult"
            data = {
                "CurrentPage": str(number),
                "TotalPages": total_pages,
                "QueryString":"SELECT DISTINCT AD.[APPLICATION_NUMBER],AD.[PATENT_NUMBER],[TITLE_OF_INVENTION],CONVERT(VARCHAR(10),[DATE_OF_FILING],103) AS Application_Date FROM [dbo].[PAT_APPLICATION_DETAILS] (Nolock) AS AD WHERE Convert(date,AD.DATE_OF_FILING) BETWEEN '01/01/%s' AND '12/31/%s'" % (self.year,self.year,),
                "ConnectionName":"PublicationConnection",
                "TotalResult": str(all_num),
                "Title":"",
                "page": str(number+1)
            }
            finish_page = number
            finish_app = number*25
            left = int(all_num)-number*25
            left_page = (int(all_num) - number * 25) / 25
            next_page = number+1
            response.meta["number"]=next_page
            time.sleep(5)
            if left_page<0:
                print u"已经到最后一页"
                return
            print(u"\n\n\n\n\n请求第%s页 完成: %s 页 %s条  剩余：%s页 %s条" % (next_page,finish_page,finish_app,left_page,left))
            yield FormRequest(page_url, meta=response.meta,formdata=data, callback=self.parse_search_list, errback=self.parse_error,dont_filter=True)

    def parse_intro(self, response):
        app_number = response.meta['app_number']
        intro_content = self.readhtml.read_intro_data(response.text)
        item = IntroItem()
        item["intro_data"]=intro_content
        item["app_num"]=app_number
        yield item
        specification_content = response.xpath("//textarea[@name='COMPLETE_SPECIFICATION']/text()").extract_first(default="")
        item = SpecificationItem()
        item["specification"] = specification_content
        item["app_num"] = app_number
        item["year"] = self.year
        item["specification_path"] = self.specification_path
        yield item
        detail_post_link = "http://ipindiaservices.gov.in/PublicSearch/PublicationSearch/GetApplicationStatus"
        detail_post_data = {
            "submit":"View Application Status",
            "COMPLETE_SPECIFICATION":specification_content,
            "ApplicationNumber":app_number
        }
        yield FormRequest(detail_post_link, formdata=detail_post_data, callback=self.parse_detail, errback=self.parse_error, meta=response.meta,dont_filter=True)
    
    def parse_detail(self, response):
        print "==> in parse_detail"
        detail_content = self.readhtml.read_detail_data(response.text)
        item = DetailItem()
        item["detail_data"] = detail_content
        item["app_num"] = response.meta['app_number']
        yield item
        full_pdf_path = self.pdf_path + item["app_num"].replace("/","_").strip()
        if self.db.get(item["app_num"].replace("/","_").strip()+"+pdf_num"):
            print item["app_num"].replace("/","_").strip(),u"pdf已经下载过，跳过"
        else:
            if not os.path.exists(full_pdf_path):
                os.makedirs(full_pdf_path)
            response.meta["full_pdf_path"] = full_pdf_path
            pdf_url = "http://ipindiaservices.gov.in/PatentSearch/PatentSearch/ViewDocuments"
            pdf_data = {
                "APPLICATION_NUMBER":response.meta['app_number'],
                "PATENT_NUMBER":"",
                "SubmitAction":"View Documents",
            }
            yield FormRequest(pdf_url, formdata=pdf_data, callback=self.parse_pdf_list, errback=self.parse_error, meta=response.meta, dont_filter=True)
    
    def parse_pdf_list(self, response):
        pdf_detail_url = "http://ipindiaservices.gov.in/PatentSearch/PatentSearch/ViewPDF"
        app_number = response.meta['app_number']
        pdf_names = response.xpath("//button[@name='DocumentName']/@value").extract()
        print u"APPNUMBER: %s 有 %s 个文件下载" % (response.meta['app_number'], len(pdf_names))
        data = {
            "APPLICATION_NUMBER":app_number
        }
        self.db.set(app_number+"+pdf_num", len(pdf_names))
        for pdf in pdf_names:
            full_pdf_path = response.meta["full_pdf_path"] + "/" + pdf
            if os.path.exists(full_pdf_path):
                continue
            response.meta["DocumentName"]=pdf
            data["DocumentName"]=pdf
            print u"==>[%s]准备下载pdf文件: %s" % (app_number,pdf)
            yield FormRequest(pdf_detail_url, formdata=data, callback=self.parse_pdf_file, errback=self.parse_error, meta=response.meta, dont_filter=True)

    def parse_pdf_file(self, response):
        pdf_name = response.meta["DocumentName"]
        full_pdf_path = response.meta["full_pdf_path"] + "/" + pdf_name
        with open(full_pdf_path, "wb+") as pdf:
            pdf.write(response.body)
            print "====>PDF: [%s]  download finished" % full_pdf_path
    
    def parse_error(self, error):
        print "ERROR: %s" % error