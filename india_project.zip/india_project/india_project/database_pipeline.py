# -*- coding: utf-8 -*-

from items import IntroItem,DetailItem,SpecificationItem,LastItem
from util.process_file import ReadHtmlAsMssql
from codecs import open
import redis
import os
import pymssql
import re
import json

class IndiaProjectDatabasePipeline(object):

    def __init__(self):
        print "====>content database..."
        self.read_html = ReadHtmlAsMssql()
        self.conn = pymssql.connect(host="192.168.1.120:1433", user="ipindia", password="123.com", database="test", charset = "utf8")
        self.cursor = self.conn.cursor()
        self.db = redis.StrictRedis(host="localhost", port=6379, db=0)
        self.error_data = open("error.csv", "a+", encoding="utf-8")

    def __del__(self):
        self.conn.close()
        print u"释放数据库连接"
        self.error_data.close()
        print u"文件关闭"

    def test_sql(self):
        sql = "SELECT ApplicationNumber FROM T_Pub_ApplicationBasedata"
        self.cursor.execute(sql)
        datas = self.cursor.fetchall()
        print datas

    def process_item(self, item, spider):
        try:
            if isinstance(item, IntroItem):
                self.read_html.save_data_to_mssql(item["intro_data"], "", self.conn)
            elif isinstance(item, DetailItem):
                self.read_html.save_data_to_mssql("", item["detail_data"], self.conn)
            elif isinstance(item, SpecificationItem):
                print "write specification==> [%s]" % item["app_num"]
                detail_link_text = item["app_num"].replace("/","_").strip()
                with open(item["specification_path"] + detail_link_text,"w+",encoding="utf-8") as sp:
                    sp.write(item["specification"])
            else:
                self.db.set(item["year"],item["new_to_date"])
            if dict(item).get("app_num"):
                detail_link_text=item["app_num"].replace("/","_").strip()
                self.db.set(detail_link_text + "-data","1")
            print "==============<PIPELELINE DONE>================"
        except Exception as e:
            print "===========>Error: %s" % e 
            self.error_data.write(e.message)
            self.error_data.write(json.dumps(item, ensure_ascii=False))
            self.error_data.write("\n")
        return item

if __name__ == "__main__":
    india = IndiaProjectDatabasePipeline()
    india.test_sql()