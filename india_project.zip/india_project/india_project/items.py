# -*- coding: utf-8 -*-

import scrapy

class IntroItem(scrapy.Item):
    app_num = scrapy.Field()
    intro_data = scrapy.Field()

class DetailItem(scrapy.Item):
    app_num = scrapy.Field()
    detail_data = scrapy.Field()

class SpecificationItem(scrapy.Item):
    year = scrapy.Field()
    app_num = scrapy.Field()
    specification = scrapy.Field()
    specification_path = scrapy.Field()
    
class LastItem(scrapy.Item):
    year=scrapy.Field()
    new_to_date=scrapy.Field()