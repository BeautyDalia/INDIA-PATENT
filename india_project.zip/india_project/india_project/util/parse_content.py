#!/usr/bin/env python
#coding:utf-8
import os
from bs4 import BeautifulSoup
import re
import time
import chardet
import datetime
import multiprocessing


class ReadHtml(object):
    def number_format(self, num):
        if num < 10 :
            return "0"+str(num)
        else :
            return str(num)
    #保存错误日志
    def error_message(self, error_path):
        time = datetime.datetime.now()
        path = os.getcwd() + "\\errors\\"
        if os.path.exists(path) is False:
            os.mkdir(path)
        path = path + str(time.year) + self.number_format(time.month) + self.number_format(time.day)
        if os.path.exists(path) is False:
            os.mkdir(path)
        file_path = path + "\\error_message.txt"
        # with open(file_path, "wb+", encoding="utf-8") as iframe_source:
        with open(file_path,"a") as iframe_source:
            iframe_body = "\n" + error_path
            iframe_source.write(iframe_body)
    #格式化key值
    def format_element_text(self,value):
        if value is None:
            value = ""
        else:
            value = "".join([i.strip() for i in value.split()])
        return "'" + value + "'"
    #格式化value值
    def format_element_value(self,value):
        if value is None:
            value = ""
        else:
            value = value.replace(":", "").replace("\"", "").replace("  ", "").replace("\n", "").replace("\'", "").replace("\\", "").strip()
        return "'" + value + "'"
        
    def read_intro_data(self, htmlcont):
        soup = BeautifulSoup(htmlcont, 'lxml')
        home = soup.find(id="home")
        if home is not None:
            trs = home.find_all("tr")
            if len(trs)>0 :
                # print(trs)
                info = "{"
                count = 0
                for i in range(0, len(trs)):
                    if i < 11:#基本信息
                        tds = trs[i].find_all("td")
                        text = self.format_element_text(tds[0].getText())
                        value = self.format_element_value(tds[1].getText())
                        line = text + ":" + value + ","
                        info += line
                    elif i == 12:#发明人
                        inventor = trs[i - 1].find("td").getText()
                        temp_trs = trs[i].find_all("tr")
                        t_th = temp_trs[0].find_all("th")
                        for k in range(0, len(temp_trs)):
                            if k > 0:
                                t_td = temp_trs[k].find_all("td")
                                for j in range(len(t_td)):
                                    th_text = self.format_element_text(inventor + " " + t_th[j].getText() + " " + str(k))
                                    td_text = self.format_element_value(t_td[j].getText())
                                    line = th_text + ":" + td_text + ","
                                    info += line
                                count += 1
                    elif i == 15 + count:#申请人
                        inventor = trs[i - 1].find("td").getText()
                        temp_trs = trs[i].find_all("tr")
                        t_th = temp_trs[0].find_all("th")
                        for k in range(0, len(temp_trs)):
                            if k > 0:
                                t_td = temp_trs[k].find_all("td")
                                for j in range(len(t_td)):
                                    th_text = self.format_element_text(inventor + " " + t_th[j].getText() + " " + str(k))
                                    td_text = self.format_element_value(t_td[j].getText())
                                    line = th_text + ":" + td_text + ","
                                    info += line
                    elif "Abstract:" in trs[i].text:#abstract
                        content = trs[i].find("td").getText()
                        temp_text = content.split(":")
                        text = self.format_element_text(temp_text[0])
                        value = self.format_element_value(temp_text[1])
                        line = text + ":" + value + ","
                        info += line
                info += "}"
                print(info)
            else :
                info = None
        else :
            info = None
        return info.replace("\n","")
        
    def read_detail_data(self, htmlcont):
        soup = BeautifulSoup(htmlcont, 'lxml')
        report = soup.find(id="Content")
        if report is not None:
            detail_tables = report.find_all("table")
            info = "{'':'',"
            for table in detail_tables:
                if table:
                    trs = table.find_all("tr")
                    for i in range(0, len(trs)):
                        tr = trs[i]
                        td = tr.find_all("td")
                        if len(td) > 1:
                            text = self.format_element_text(td[0].getText())
                            value = self.format_element_value(td[1].getText())
                            line = text + ":" + value
                            # if i + 1 < len(trs):
                            line += ","
                            info += line
            info += ",'':''}"
            print(info)
        else :
            info = None
        return info.replace("\n","")

    # 读取detail.html中的数据
    def read_detail_data_old(self, htmlcont):
        # 对获取到的文本进行解析
        soup = BeautifulSoup(htmlcont, 'lxml')
        report = soup.find(id="Reportprint")
        if report is not None:
            # table = report.find_all("table")[1]
            detail_tables = report.find_all("table")
            info = "{'':'',\n"
            for table in detail_tables:
                if table:
                    trs = table.find_all("tr")
                    for i in range(0, len(trs)):
                        tr = trs[i]
                        td = tr.find_all("td")
                        if len(td) > 1:
                            text = self.format_element_text(td[0].getText())
                            value = self.format_element_value(td[1].getText())
                            line = text + ":" + value
                            # if i + 1 < len(trs):
                            line += ",\n"
                            info += line
            tables = soup.find(id="panelReport")
            status_table = tables.find_all("table")
            index = len(status_table) - 2
            trs = status_table[index].find_all("tr")
            for i in range(0, len(trs)):
                tr = trs[i]
                td = tr.find_all("td")
                if len(td) > 1:
                    text = self.format_element_text(td[0].getText())
                    value = self.format_element_value(td[1].getText())
                    line = text + ":" + value
                    line += ",\n"
                    info += line
            info += ",'':''}"
            print(info)
        else:
            info = None
        return info