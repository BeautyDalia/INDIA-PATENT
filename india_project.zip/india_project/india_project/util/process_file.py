#!coding:utf-8
# coding:utf-8

import pymssql
import os
from bs4 import BeautifulSoup
import re
import time
import chardet
import datetime
import multiprocessing
from codecs import open

class ReadHtmlAsMssql():
    def number_format(self, num):
        if num < 10 :
            return "0"+str(num)
        else :
            return str(num)
    #读取导的数据入库
    def save_data_to_mssql(self, intro_data, detail_data, conn):
        cursor=self.conn.cursor()
        intro_data = intro_data.replace('"",,""','"",""')
        detail_data = detail_data.replace('"",,""','"",""')
        if intro_data:
            intro_data = re.sub('\'', '\"', intro_data)
            try:
                intro_content = eval(intro_data)
            except Exception as e:
                return 
            # 公共基本信息表
            cursor.execute(
                """insert into T_Pub_ApplicationBasedata select '%s','%s',%s,'%s','%s'
                  ,%s,'%s','%s',%s,'%s','%s','%s','%s','%s','%s','%s','%s','%s')
               """ % (intro_content['InventionTitle']  # 标题
                                  , intro_content["PublicationNumber"]  # 公开号
                                  , self.date_null_if('PublicationDate',intro_content)  # 公开日
                                  , intro_content['PublicationType']  # 公开类型
                                  , intro_content['ApplicationNumber']  # 申请号
                                  , self.date_null_if('ApplicationFilingDate',intro_content)  # 申请日期
                                  , intro_content["PriorityNumber"]  # 优先权数
                                  , intro_content["PriorityCountry"]  # 优先权地区
                                  , self.date_null_if("PriorityDate",intro_content)  # 优先权日期
                                  , intro_content["FieldOfInvention"]  # 领域的发明
                                  , intro_content["Classification(IPC)"]  # 分类IPC
                                  , intro_content["Abstract"]  # Abstract
                                  , '', '', '', '', '', ''
                      ))
            conn.commit()
            # 公共申请人表
            count = 1
            while (True):
                str_count = str(count)
                if ("ApplicantName" + str_count) in intro_content:
                    cursor.execute(
                        """insert into T_Pub_Applicat select '%s','%s','%s','%s','%s')
                        """ % (intro_content['ApplicationNumber']
                                   , intro_content["ApplicantName" + str_count]
                                   , intro_content['ApplicantAddress' + str_count]
                                   , intro_content['ApplicantCountry' + str_count]
                                   , intro_content['ApplicantNationality' + str_count]))
                    count += 1
                    conn.commit()
                else:
                    break
            # 公共发明人表
            count = 1
            while (True):
                str_count = str(count)
                if ("InventorName" + str_count) in intro_content:
                    cursor.execute(
                        """insert into T_Pub_Inventor select '%s','%s','%s','%s','%s')
                       """ % (intro_content['ApplicationNumber']
                                  , intro_content["InventorName" + str_count]
                                  , intro_content['InventorAddress' + str_count]
                                  , intro_content['InventorCountry' + str_count]
                                  , intro_content['InventorNationality' + str_count]
                            ))
                    count += 1
                    conn.commit()
                else:
                    break
        if detail_data:
            detail_data = re.sub('\'', '\"', detail_data)
            detail_data = detail_data.replace(",\n,", ',\n').replace(',,',',')
            detail_content = eval(detail_data)
            # 公开详细信息表
            cursor.execute(
                """insert into T_Pub_Detail select '%s','%s',%s,'%s','%s'
                  ,'%s',%s,%s,'%s',%s,'%s','%s','%s','%s','%s' )
               """ % (detail_content['APPLICATIONNUMBER']  # 申请号
                                  , self.null_if("APPLICANTNAME",detail_content)  # 申请人
                                  , self.date_null_if('DATEOFFILING',detail_content)  # 提交日期
                                  , self.null_if('E-MAIL(AsPerRecord)',detail_content)  # 邮箱
                                  , self.null_if('ADDITIONAL-EMAIL(AsPerRecord)',detail_content)  # 额外邮箱
                                  , self.null_if('E-MAIL(UPDATEDOnline)',detail_content)  # 在线更新
                                  , self.date_null_if("DATEOFCOMPLETESPECIFICATION",detail_content)  # 完全规格日期
                                  , self.date_null_if("PRIORITYDATE",detail_content)  # 优先权日期
                                  , self.null_if("TITLEOFINVENTION",detail_content) # 发明名称
                                  , self.date_null_if("PUBLICATIONDATE(U/S11A)",detail_content)  # 公开日期
                                  , '', '', '', '', ''
                      ))
            conn.commit()
            if self.null_if("Status",detail_content) is not None :
                cursor.execute("update T_Pub_ApplicationBasedata set status='%s' where ApplicationNumber='%s'" %(
                    self.null_if("Status", detail_content),detail_content['APPLICATIONNUMBER']
                ))
                conn.commit()
        print('*****')
    def null_if(self, column, content):
        if column not in content :
            return ''
        else:
            if content[column] is 'NA':
                return ''
            else :
                return content[column]
    #日期格式化
    def date_null_if(self, column, content):
        if column not in content :
            return "convert(date,null,103)"
        else:
            if content[column] is 'NA':
                return "convert(date,null,103)"
            else :
                return "convert(date,'%s',103)"%content[column][0:10]


